package com.grburger.pos

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.grburger.pos.data.PosDatabase
import com.grburger.pos.data.SaleEntity
import com.grburger.pos.data.SaleItemEntity
import com.grburger.pos.printing.BluetoothTicketPrinter
import com.grburger.pos.printing.TicketItem
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class Product(val name: String, val price: Long)
private val menu = listOf(
    Product("GR JUNIOR",15000), Product("V-0",18000), Product("V-1",24000),
    Product("V-2",24000), Product("V-3",24000), Product("V-4",28000),
    Product("ONION",24000), Product("BIG GR",30000), Product("LOMITO",24000),
    Product("Papas clásicas",10000), Product("Papas cheddar",20000),
    Product("Papas Katupiry",20000), Product("Bastoncitos de pollo",20000)
)
private fun money(v: Long) = "Gs. " + "%,d".format(Locale("es","PY"),v)

class MainActivity : ComponentActivity() {
    private val printer = BluetoothTicketPrinter()
    private val requestBluetooth = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private var selectedDeviceAddress by mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = PosDatabase.get(this).salesDao()
        setContent {
            var cart by remember { mutableStateOf<Map<String, Int>>(emptyMap()) }
            var payment by remember { mutableStateOf("Efectivo") }
            var customer by remember { mutableStateOf("") }
            var status by remember { mutableStateOf("Ventas guardadas en este dispositivo.") }
            var saleHistory by remember { mutableStateOf<List<com.grburger.pos.data.SaleWithItems>>(emptyList()) }
            LaunchedEffect(Unit) { dao.observeSales().collect { saleHistory = it } }
            val total = cart.entries.sumOf { (name, qty) -> (menu.first { it.name == name }.price * qty) }

            MaterialTheme {
                Scaffold(topBar = { TopAppBar(title = { Text("GR BURGER POS") }) }) { pad ->
                    LazyColumn(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        item { Text("NUEVA VENTA", style = MaterialTheme.typography.titleLarge) }
                        item { OutlinedTextField(customer, { customer = it }, label = { Text("Cliente (opcional)") }, modifier = Modifier.fillMaxWidth()) }
                        item { Text("MENÚ", style = MaterialTheme.typography.titleMedium) }
                        items(menu) { p ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column(Modifier.weight(1f)) { Text(p.name); Text(money(p.price), style = MaterialTheme.typography.bodySmall) }
                                Button(onClick = { cart = cart + (p.name to ((cart[p.name] ?: 0) + 1)) }) { Text("Agregar") }
                            }
                            HorizontalDivider()
                        }
                        item { Text("PEDIDO", style = MaterialTheme.typography.titleMedium) }
                        items(cart.entries.toList()) { entry ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("${entry.value} x ${entry.key}")
                                Row {
                                    TextButton(onClick = { cart = cart + (entry.key to (entry.value - 1)); if ((cart[entry.key] ?: 0) <= 0) cart = cart - entry.key }) { Text("−") }
                                    TextButton(onClick = { cart = cart + (entry.key to (entry.value + 1)) }) { Text("+") }
                                }
                            }
                        }
                        item {
                            Text("Total: ${money(total)}", style = MaterialTheme.typography.titleLarge)
                            Text("Forma de pago")
                            Row {
                                FilterChip(selected = payment == "Efectivo", onClick = { payment = "Efectivo" }, label = { Text("Efectivo") })
                                Spacer(Modifier.width(8.dp))
                                FilterChip(selected = payment == "Transferencia", onClick = { payment = "Transferencia" }, label = { Text("Transferencia") })
                            }
                            Button(
                                enabled = cart.isNotEmpty(),
                                modifier = Modifier.fillMaxWidth(),
                                onClick = {
                                    lifecycleScope.launch {
                                        val now = System.currentTimeMillis()
                                        val number = "GR-" + SimpleDateFormat("yyMMdd-HHmmss", Locale.US).format(Date(now))
                                        val items = cart.map { (name, qty) ->
                                            val p = menu.first { it.name == name }
                                            SaleItemEntity(saleId = 0, productName = name, quantity = qty, unitPrice = p.price, lineTotal = p.price * qty)
                                        }
                                        dao.saveSale(SaleEntity(saleNumber = number, createdAt = now, customer = customer, paymentMethod = payment, total = total), items)
                                        status = "Venta $number guardada. Pendiente de imprimir."
                                        cart = emptyMap()
                                        customer = ""
                                    }
                                }
                            ) { Text("REGISTRAR VENTA") }
                            Text(status, style = MaterialTheme.typography.bodySmall)
                        }
                        item { Text("HISTORIAL DE VENTAS", style = MaterialTheme.typography.titleMedium) }
                        items(saleHistory.take(20)) { sale ->
                            Card {
                                Column(Modifier.padding(12.dp)) {
                                    Text("${sale.sale.saleNumber} · ${money(sale.sale.total)}")
                                    Text("${sale.sale.paymentMethod} · ${sale.sale.printStatus}", style = MaterialTheme.typography.bodySmall)
                                    TextButton(onClick = {
                                        status = "Para imprimir, primero seleccioná la impresora Bluetooth emparejada. La selección de impresora se habilitará en el siguiente paso."
                                    }) { Text("Imprimir ticket") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
