package com.grburger.pos.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "sales")
data class SaleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val saleNumber: String,
    val createdAt: Long,
    val customer: String,
    val paymentMethod: String,
    val total: Long,
    val printStatus: String = "PENDING"
)

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val price: Long,
    val category: String = "General",
    val description: String = "",
    val active: Boolean = true
)

@Entity(tableName = "addons")
data class AddonEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val price: Long,
    val active: Boolean = true
)

@Entity(tableName = "sale_items")
data class SaleItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val saleId: Long,
    val productName: String,
    val quantity: Int,
    val unitPrice: Long,
    val lineTotal: Long,
    val selectedAddons: String = ""
)

data class SaleWithItems(
    @Embedded val sale: SaleEntity,
    @Relation(parentColumn = "id", entityColumn = "saleId")
    val items: List<SaleItemEntity>
)

@Dao
interface SalesDao {
    @Transaction
    @Query("SELECT * FROM sales ORDER BY createdAt DESC")
    fun observeSales(): Flow<List<SaleWithItems>>

    @Insert
    suspend fun insertSale(sale: SaleEntity): Long

    @Insert
    suspend fun insertItems(items: List<SaleItemEntity>)

    @Transaction
    suspend fun saveSale(sale: SaleEntity, items: List<SaleItemEntity>): Long {
        val id = insertSale(sale)
        insertItems(items.map { it.copy(saleId = id) })
        return id
    }

    @Query("UPDATE sales SET printStatus = :status WHERE id = :saleId")
    suspend fun updatePrintStatus(saleId: Long, status: String)
}

@Dao
interface CatalogDao {
    @Query("SELECT * FROM products WHERE active = 1 ORDER BY category, name")
    fun observeProducts(): Flow<List<ProductEntity>>

    @Insert
    suspend fun addProduct(product: ProductEntity): Long

    @Update
    suspend fun updateProduct(product: ProductEntity)

    @Query("UPDATE products SET active = 0 WHERE id = :id")
    suspend fun deactivateProduct(id: Long)

    @Query("SELECT * FROM addons WHERE active = 1 ORDER BY name")
    fun observeAddons(): Flow<List<AddonEntity>>

    @Insert
    suspend fun addAddon(addon: AddonEntity): Long

    @Update
    suspend fun updateAddon(addon: AddonEntity)

    @Query("UPDATE addons SET active = 0 WHERE id = :id")
    suspend fun deactivateAddon(id: Long)
}

@Database(entities = [SaleEntity::class, SaleItemEntity::class, ProductEntity::class, AddonEntity::class], version = 2, exportSchema = false)
abstract class PosDatabase : RoomDatabase() {
    abstract fun salesDao(): SalesDao
    abstract fun catalogDao(): CatalogDao
    companion object {
        @Volatile private var INSTANCE: PosDatabase? = null
        fun get(context: Context): PosDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext, PosDatabase::class.java, "gr_burger_pos.db"
            ).fallbackToDestructiveMigration().build().also { INSTANCE = it }
        }
    }
}
