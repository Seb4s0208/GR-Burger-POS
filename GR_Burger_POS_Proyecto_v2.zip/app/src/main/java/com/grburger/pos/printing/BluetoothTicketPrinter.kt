package com.grburger.pos.printing

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class BluetoothTicketPrinter {
    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    @SuppressLint("MissingPermission")
    fun pairedPrinters(adapter: BluetoothAdapter): List<BluetoothDevice> =
        adapter.bondedDevices?.toList()?.sortedBy { it.name ?: it.address } ?: emptyList()

    @SuppressLint("MissingPermission")
    fun print(
        device: BluetoothDevice,
        saleNumber: String,
        customer: String,
        payment: String,
        items: List<TicketItem>,
        total: Long
    ) {
        var socket: BluetoothSocket? = null
        try {
            socket = device.createRfcommSocketToServiceRecord(sppUuid)
            socket.connect()
            val out = socket.outputStream
            out.write(byteArrayOf(0x1B, 0x40)) // ESC @ initialize
            out.write(byteArrayOf(0x1B, 0x61, 0x01)) // center
            writeText(out, "GR BURGER\n")
            writeText(out, "COMPROBANTE DE VENTA\n")
            out.write(byteArrayOf(0x1B, 0x61, 0x00)) // left
            writeText(out, "--------------------------------\n")
            writeText(out, "Pedido: $saleNumber\n")
            writeText(out, "Fecha: ${SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("es", "PY")).format(Date())}\n")
            if (customer.isNotBlank()) writeText(out, "Cliente: $customer\n")
            writeText(out, "--------------------------------\n")
            items.forEach {
                writeText(out, "${it.quantity} x ${it.name}\n")
                writeText(out, "   ${money(it.unitPrice)}    ${money(it.unitPrice * it.quantity)}\n")
            }
            writeText(out, "--------------------------------\n")
            writeText(out, "TOTAL: ${money(total)}\n")
            writeText(out, "Pago: $payment\n")
            writeText(out, "\nGracias por tu compra!\n\n\n")
            out.write(byteArrayOf(0x1D, 0x56, 0x00)) // partial cut (if supported)
            out.flush()
        } finally {
            try { socket?.close() } catch (_: Exception) {}
        }
    }

    private fun writeText(out: OutputStream, text: String) {
        out.write(text.toByteArray(Charsets.UTF_8))
    }
    private fun money(value: Long) = "Gs. " + "%,d".format(Locale("es", "PY"), value)
}

data class TicketItem(val name: String, val quantity: Int, val unitPrice: Long)
