package com.grburger.pos

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.grburger.pos.data.AddonEntity
import com.grburger.pos.data.CatalogDao
import com.grburger.pos.data.ProductEntity
import kotlinx.coroutines.launch

@Composable
fun AdminCatalogScreen(dao: CatalogDao, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val products by dao.observeProducts().collectAsState(initial = emptyList())
    val addons by dao.observeAddons().collectAsState(initial = emptyList())
    var name by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Hamburguesas") }
    var description by remember { mutableStateOf("") }
    var addonName by remember { mutableStateOf("") }
    var addonPrice by remember { mutableStateOf("") }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Administrar menú") }, navigationIcon = {
            TextButton(onClick = onBack) { Text("Volver") }
        })
    }) { padding ->
        LazyColumn(
            Modifier.padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item { Text("AGREGAR PRODUCTO", style = MaterialTheme.typography.titleMedium) }
            item { OutlinedTextField(name, { name = it }, label = { Text("Nombre") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(price, { price = it.filter(Char::isDigit) }, label = { Text("Precio en guaraníes") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(category, { category = it }, label = { Text("Categoría") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(description, { description = it }, label = { Text("Descripción (opcional)") }, modifier = Modifier.fillMaxWidth()) }
            item {
                Button(
                    enabled = name.isNotBlank() && (price.toLongOrNull() ?: 0L) > 0,
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        scope.launch {
                            dao.addProduct(ProductEntity(
                                name = name.trim(), price = price.toLong(),
                                category = category.trim().ifBlank { "General" },
                                description = description.trim()
                            ))
                            name = ""; price = ""; description = ""
                        }
                    }
                ) { Text("Guardar producto") }
            }
            item { HorizontalDivider(); Text("PRODUCTOS CARGADOS", style = MaterialTheme.typography.titleMedium) }
            items(products) { product ->
                Card {
                    Column(Modifier.padding(12.dp)) {
                        Text(product.name, style = MaterialTheme.typography.titleSmall)
                        Text("Gs. ${product.price} · ${product.category}")
                        if (product.description.isNotBlank()) Text(product.description)
                        Row {
                            TextButton(onClick = {
                                name = product.name; price = product.price.toString()
                                category = product.category; description = product.description
                                scope.launch { dao.deactivateProduct(product.id) }
                            }) { Text("Editar (recargar)") }
                            TextButton(onClick = { scope.launch { dao.deactivateProduct(product.id) } }) { Text("Desactivar") }
                        }
                    }
                }
            }
            item { HorizontalDivider(); Text("AGREGADOS / EXTRAS", style = MaterialTheme.typography.titleMedium) }
            item { OutlinedTextField(addonName, { addonName = it }, label = { Text("Nombre del agregado") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(addonPrice, { addonPrice = it.filter(Char::isDigit) }, label = { Text("Precio del agregado") }, modifier = Modifier.fillMaxWidth()) }
            item {
                Button(
                    enabled = addonName.isNotBlank() && (addonPrice.toLongOrNull() ?: 0L) >= 0,
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        scope.launch {
                            dao.addAddon(AddonEntity(name = addonName.trim(), price = addonPrice.toLong()))
                            addonName = ""; addonPrice = ""
                        }
                    }
                ) { Text("Guardar agregado") }
            }
            items(addons) { addon ->
                ListItem(
                    headlineContent = { Text(addon.name) },
                    supportingContent = { Text("Gs. ${addon.price}") },
                    trailingContent = { TextButton(onClick = { scope.launch { dao.deactivateAddon(addon.id) } }) { Text("Desactivar") } }
                )
            }
        }
    }
}
