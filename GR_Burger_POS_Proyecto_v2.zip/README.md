# GR Burger POS — versión inicial de desarrollo

Este es un proyecto Android nativo inicial (Kotlin + Jetpack Compose + Room).

## Incluye
- Catálogo inicial con los productos y precios proporcionados para GR Burger.
- Carrito y cálculo de total.
- Registro persistente de ventas y líneas de venta en SQLite mediante Room.
- Historial local de ventas.
- Módulo inicial de impresión ESC/POS por Bluetooth clásico (SPP) en `BluetoothTicketPrinter.kt`.

## Pendiente antes de usar en el negocio
- Terminar el selector de impresora Bluetooth en la interfaz y gestionar permisos en Android 12+.
- Confirmar el protocolo ESC/POS/SPP de la LUO LU-SY30 y probar codificación de caracteres/acento y corte.
- Implementar caja, gastos e inventario con movimientos auditables.
- Implementar sincronización entre dispositivos por LAN, con identificadores únicos y resolución de conflictos.
- Pruebas físicas, manejo de errores y copias de seguridad.

## Cómo abrir
Abrir la carpeta del proyecto con Android Studio (JDK 17 recomendado), sincronizar Gradle y compilar en un dispositivo Android.

**Aviso:** este código es un punto de partida de desarrollo, no un APK terminado ni un sistema validado para producción. La sincronización entre celular y tablet aún no está implementada. La impresión Bluetooth está preparada como módulo ESC/POS/SPP, pero necesita integración en pantalla y prueba con el modelo real.


## Administración editable (módulo inicial añadido)
- Entidades locales para productos y agregados/extras.
- DAO para listar, crear, editar por recarga/desactivar productos y crear/desactivar extras.
- Pantalla `AdminCatalogScreen` con formularios para cargar productos, categorías, descripción y extras.
- Los cambios se guardan localmente con Room; no requieren internet.

### Integración pendiente
La pantalla de administración está creada como componente y debe conectarse desde la navegación principal. También falta completar la edición en línea sin desactivar/recrear, vincular extras a productos concretos, mostrar extras en el carrito y en el ticket, y sincronizar catálogo entre dispositivos.


## Compilación en la nube desde celular/tablet (sin PC)
Se añadió `.github/workflows/build-apk.yml` para compilar el APK de depuración mediante GitHub Actions.
Pasos generales:
1. Crear una cuenta o iniciar sesión en GitHub desde el navegador Android.
2. Crear un repositorio nuevo y subir el contenido de este ZIP (descomprimir primero; incluir archivos ocultos como `.github`).
3. Abrir la pestaña Actions del repositorio y ejecutar "Build GR Burger POS APK" si no se ejecutó automáticamente.
4. Al terminar correctamente, abrir la ejecución y descargar el artefacto `GR-Burger-POS-debug`.
5. Descomprimir el artefacto y abrir `app-debug.apk` en el Android para instalarlo.

Nota: esta configuración automatiza una compilación de depuración; no convierte el proyecto en una app terminada ni certifica la compatibilidad con la impresora. El código sigue siendo una versión de desarrollo y necesita pruebas y completar módulos antes de usarlo para ventas reales.
